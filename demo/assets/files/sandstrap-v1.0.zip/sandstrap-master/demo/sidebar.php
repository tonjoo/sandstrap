<div class="sidebar">
    <ul>
        <li class="js-target-scroll"><a href="#advantages">Advantages</a></li>
        <li class="js-target-scroll"><a href="#installation">Installation</a></li>
        <li class="js-target-scroll"><a href="#build-system">Build System</a></li>
        <li class="js-target-scroll"><a href="#js">JS</a></li>
        <li class="js-target-scroll"><a href="#breakpoint">Breakpoint</a></li>
        <li class="js-target-scroll"><a href="#grid-example">Grid Example</a></li>
        <li class="js-target-scroll"><a href="#utilities">Utilities</a></li>
        <li class="js-target-scroll"><a href="#pagination">Pagination</a></li>
        <li class="js-target-scroll"><a href="#breadcrumb">Breadcrumb</a></li>
        <li class="js-target-scroll"><a href="#typography">Typography</a></li>
        <li class="js-target-scroll"><a href="#icon">Icon</a></li>
        <li class="js-target-scroll"><a href="#share">Share</a></li>
        <li class="js-target-scroll"><a href="#button">Button</a></li>
        <li class="js-target-scroll"><a href="#form">Form</a></li>
        <li class="js-target-scroll"><a href="#header-footer">Header Footer</a></li>
    </ul>
</div>